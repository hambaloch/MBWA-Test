<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'mangobaaz');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '[duP<Qll$4Yc_sri>:VU=D}EiZaz]&Rax/-DJz=+<`6xq#rzy0xs?t9s1E(e/um ');
define('SECURE_AUTH_KEY',  '#Y9vY>sX~$#Q:)@d3Dw.AM4I+^otVmq*=jVVZ[Jv/^1rKx5z3~8W6xS%j(LwcJ?[');
define('LOGGED_IN_KEY',    'MJ ~TXnZo4MX?Pp=(B*5]q:@mKly8@ ]9{a`M&I/,CFPBB9&M&lmnF3gu,n%/Qw9');
define('NONCE_KEY',        'xy|HbTV/rD[|0P!H3p/E8heU0,c7sjl|awPaFIv*6<+_)%z#+Ip0E&3MN~-|Y1RA');
define('AUTH_SALT',        '{HJY5&3st1!4gB$b{pL|E0{OpX0w+C3H,TV-`Vo^WPJTaH?0o{yj|M,$r^B~mZ<c');
define('SECURE_AUTH_SALT', 'z?%=?;fZ&Z*rso~32T3v9W5,gJ]KYjlp2u>3utdfgm9.L1hi2}1E1D-EMyV>~5r7');
define('LOGGED_IN_SALT',   '/]XH`U5^~SJ!C{5+o.%2&K8$ +0_;9(Ttsm5~V@kY0G$!gb~^i}mc~mgR9]UOB.B');
define('NONCE_SALT',       'H]wyLB6!t*^8h[NPzyC^ZINqR(;^$..#.[`/f<P[kJ)N[n/!,Hb&Go51flstbVwO');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
